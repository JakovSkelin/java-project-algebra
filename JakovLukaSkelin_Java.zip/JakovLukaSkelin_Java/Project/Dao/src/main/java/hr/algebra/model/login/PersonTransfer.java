/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package hr.algebra.model.login;

import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.Transferable;
import java.awt.datatransfer.UnsupportedFlavorException;
import java.io.IOException;

/**
 *
 * @author jlskelin
 */
public class PersonTransfer implements Transferable {
    
    public static final DataFlavor PERSON_FLAVOR = new DataFlavor(Person.class, "Person");
    public static final DataFlavor[] SUPPORTED_FLAVORS = {PERSON_FLAVOR};
    
    private final Person person;

    public PersonTransfer(Person person) {
        this.person = person;
    }

    @Override
    public DataFlavor[] getTransferDataFlavors() {
        return SUPPORTED_FLAVORS;
    }

    @Override
    public boolean isDataFlavorSupported(DataFlavor flavor) {
        return flavor.equals(PERSON_FLAVOR);
    }

    @Override
    public Object getTransferData(DataFlavor flavor) throws UnsupportedFlavorException, IOException {
        if (isDataFlavorSupported(flavor)) {
            return person;
        }
        
        throw new UnsupportedFlavorException(flavor);
    } 
    
}
