/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utils;

import java.text.CharacterIterator;
import java.text.StringCharacterIterator;

/**
 *
 * @author jlskelin
 */
public class NumberUtils {
    public static boolean isPositiveInteger(String data){
        if (data.isEmpty()) {
            return false;
        }
        CharacterIterator iterator = new StringCharacterIterator(data);
        while (iterator.current() != CharacterIterator.DONE) {
            if (!Character.isDigit(iterator.current())) {
                return false;
            }
            iterator.next();
            
        }
        return true;
    }
}
